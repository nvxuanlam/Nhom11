
# TechShop - ConsoleApp Style + SQL Server

Dự án được làm lại theo cấu trúc Visual Studio giống ảnh:
- `QL_TechShop_Nhom11.sln`
- thư mục project `QL_TechShop_Nhom11`
- file SQL `SQLQuery2.sql`

## Cách chạy

### 1. Tạo database
Mở SQL Server Management Studio, chạy file:

```sql
SQLQuery2.sql
```

File này tạo database `TechShopDB`, bảng sản phẩm, tài khoản, đơn hàng, chi tiết đơn hàng, lịch sử tồn kho.

### 2. Mở project
Mở file:

```text
QL_TechShop_Nhom11.sln
```

bằng Visual Studio.

### 3. Kiểm tra connection string
Trong file:

```text
QL_TechShop_Nhom11/appsettings.json
```

Nếu dùng Windows Authentication để nguyên:

```json
"Server=.;Database=TechShopDB;Trusted_Connection=True;TrustServerCertificate=True;"
```

Nếu dùng SQL Authentication thì đổi thành:

```json
"Server=.;Database=TechShopDB;User Id=sa;Password=123456;TrustServerCertificate=True;"
```

### 4. Chạy web
Nhấn `F5` hoặc chạy:

```bash
dotnet run
```

Mở trình duyệt theo link Visual Studio hiện ra, ví dụ:

```text
https://localhost:7000
```

## Tài khoản demo

Admin:
```text
admin@techshop.vn
Admin123
```

Khách:
```text
user@test.vn
User1234
```

## Ghi chú
Giao diện được giữ lại từ file `preview(1).html`, phần dữ liệu sản phẩm/đơn hàng đã chuyển sang SQL Server thông qua API trong `Program.cs`.
